//
//  CardsScanner.h
//  CardsScanner
//
//  Created by Vadim Shilov on 21/11/2019.
//  Copyright © 2019 RTLabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CardIO.h"

//! Project version number for CardsScanner.
FOUNDATION_EXPORT double CardsScannerVersionNumber;

//! Project version string for CardsScanner.
FOUNDATION_EXPORT const unsigned char CardsScannerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CardsScanner/PublicHeader.h>


